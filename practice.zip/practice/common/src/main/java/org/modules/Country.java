package org.modules;

import java.io.Serializable;

public enum Country implements Serializable {
    VATICAN,
    THAILAND,
    SOUTH_KOREA,
    NORTH_KOREA,
    JAPAN;
}
