package org.modules;

import java.io.Serializable;

public enum Semester implements Serializable {
    FIRST,
    THIRD,
    FOURTH,
    SIXTH;
}
