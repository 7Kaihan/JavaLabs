package org.server;

import org.collection.StudyGroupCollectionManager;
import org.commands.CommandType;
import org.commands.Commandable;
import org.commands.ServerCommandManager;
import org.connection.AnswerMsg;
import org.connection.Request;
import org.connection.Response;
import org.exceptions.*;
import org.file.FileManager;
import org.connection.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.AlreadyBoundException;
import java.time.ZonedDateTime;

public class Server extends Thread  {
    private InetSocketAddress clientAddress;
    private ServerSocket serverSocket;
    private Socket socket;
    private int port;
    private ServerCommandManager commandManager;
    private FileManager fileManager;
    private StudyGroupCollectionManager studyGroupCollectionManager;

    private volatile boolean running = true;

    private void init(int port,String path)throws ConnectionException{
        running = true;
        this.port = port;
        studyGroupCollectionManager = new StudyGroupCollectionManager();
        fileManager = new FileManager(path);
        commandManager = new ServerCommandManager(this);
        studyGroupCollectionManager.csvDeserializer(fileManager.read());
        host(port);
        setName("server thread");
    }
    private void host(int port)throws ConnectionException{
        try{
            serverSocket = new ServerSocket(port);
        }
        catch (AlreadyBoundException exception){
            throw new PortAlreadyInUseException();
        }catch (IllegalArgumentException exception){
            throw new InvalidPortException();
        }catch (IOException exception){
            throw new ConnectionException("something went wrong during server initialization");
        }
    }
    public Server(int port, String path)throws ConnectionException{
        init(port,path);
    }
    public Request receive()throws ConnectionException, InvalidDataException{
        try {
            clientAddress = new InetSocketAddress("localhost",port);
            socket = serverSocket.accept();
            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
            Request req = (Request) objectInputStream.readObject();
            return req;
        }catch (ClassNotFoundException |  ClassCastException | IOException exception){
            throw new InvalidReceivedDataException();
        }
    }

    public void send(Response response)throws ConnectionException{
        if(clientAddress==null)throw new InvalidAddressException();
        try{
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
            objectOutputStream.writeObject(response);
            objectOutputStream.flush();
        }catch (Exception exception){
            System.out.println("something went wrong while sending data from the server");
        }
    }
    @Override
    public void run(){
        while(running){
            AnswerMsg answerMsg = new AnswerMsg();
            try{
                try{
                    Request commandMsg = receive();
                    if(commandMsg.getStudyGroup() !=null){
                        commandMsg.getStudyGroup().setCreationDate(ZonedDateTime.now());
                    }
                    if(commandManager.getCommand(commandMsg).getType() == CommandType.SERVER_ONLY){
                        throw new ServerOnlyCommandException();
                    }
                    answerMsg = commandManager.runCommand(commandMsg);
                    if(answerMsg.getStatus() == Status.EXIT){
                        close();
                    }
                }catch (CommandException exception){
                    answerMsg.error(exception.getMessage());
                }
                send(answerMsg);
            }catch (ConnectionException | InvalidDataException exception){

            }
        }
    }
    public void consoleMode(){
        commandManager.consoleMode();
    }

    public void close() {
        try{
            running = false;
            serverSocket.close();
        }catch (IOException exception){

        }
    }
    public Commandable getCommandManager(){
        return commandManager;
    }
    public FileManager getFileManager(){
        return fileManager;
    }
    public StudyGroupCollectionManager getStudyGroupCollectionManager(){
        return studyGroupCollectionManager;
    }
}
