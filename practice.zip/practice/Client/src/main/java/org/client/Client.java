package org.client;


import org.commands.ClientCommandManager;
import org.connection.Request;
import org.connection.Response;
import org.exceptions.*;
import java.io.*;
import java.net.*;


/**
 * client class
 */
public class Client extends  Thread {
    private SocketAddress address;
    private Socket socket;
    public final int MAX_TIME_OUT = 1000;
    public final int MAX_ATTEMPTS = 3;

    private boolean running;
    private ClientCommandManager commandManager;

    /**
     * initialize client
     * @param addr
     * @param p
     * @throws ConnectionException
     */
    private void init(String addr, int p) throws ConnectionException {
        connect(addr,p);
        running = true;
        commandManager = new ClientCommandManager(this);
        setName("client thread");
    }

    public Client(String addr, int p) throws ConnectionException{
        init(addr,p);
    }

    /**
     * connects client to server
     * @param addr
     * @param p
     * @throws ConnectionException
     */
    public void connect(String addr, int p) throws ConnectionException{
        try{
            address = new InetSocketAddress(InetAddress.getByName(addr),p);
        }
        catch(UnknownHostException e){
            throw new InvalidAddressException();
        }
        catch(IllegalArgumentException e){
            throw new InvalidPortException();
        }
        try {
            socket = new Socket(addr,p);
            socket.setSoTimeout(MAX_TIME_OUT);
        } catch (IOException e) {
            throw new ConnectionException("cannot open socket");
        }
    }

    /**
     * sends request to server
     * @param request
     * @throws ConnectionException
     */
    public void send(Request request) throws ConnectionException{
        try{
              ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
              objectOutputStream.writeObject(request);
              objectOutputStream.close();
        }
        catch (IOException e){
            throw new ConnectionException("something went wrong while sending request");
        }
    }

    /**
     * receive message from server
     * @return
     * @throws ConnectionException
     * @throws InvalidDataException
     */
    public Response receive()throws ConnectionException, InvalidDataException{
        try {
            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
            return (Response) objectInputStream.readObject();
        } catch (ClassNotFoundException|ClassCastException|IOException e) {
            throw new InvalidReceivedDataException();
        }
    }

    /**
     * runs client until interrupt
     */
    @Override
    public void run(){
        commandManager.consoleMode();
        close();
    }

    /**
     * close client
     */
    public void close() {
        running = false;
        commandManager.close();
        try {
            socket.close();
        }catch (IOException exception){
            System.err.println("can't close the Socket");
        }
    }
}