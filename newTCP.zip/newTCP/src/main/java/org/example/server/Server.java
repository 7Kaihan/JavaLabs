package org.example.server;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

public class Server {
    private ServerSocketChannel channel;
    public Server()throws Exception{
        channel = ServerSocketChannel.open();
        channel.bind(new InetSocketAddress(8080));
        while(true){
            SocketChannel socketChannel = channel.accept();
            ByteBuffer buffer = ByteBuffer.allocate(1024);
            int numBytesRead = socketChannel.read(buffer);
            String data = new String(buffer.array(),0,numBytesRead);
            String response = "Received : "+ data;
            ByteBuffer responseBuffer = ByteBuffer.wrap(response.getBytes());
            socketChannel.write(responseBuffer);
        }
    }
}
