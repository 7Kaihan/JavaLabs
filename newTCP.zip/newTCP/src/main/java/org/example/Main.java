package org.example;

import org.example.server.Server;

public class Main {
    public static void main(String[] args) {
        try{
            Server server = new Server();
        }catch (Exception exception){
            System.err.println("server exception");
        }
    }
}