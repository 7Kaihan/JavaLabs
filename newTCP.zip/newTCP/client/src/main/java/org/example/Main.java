package org.example;

import org.example.client.Client;

public class Main {
    public static void main(String[] args) {
        try{
            Client client = new Client();
        }catch (Exception exception){
            System.err.println("client exception");
        }
    }
}