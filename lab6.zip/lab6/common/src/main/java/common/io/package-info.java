/**
 * package for operating with user input and output
 */
package common.io;