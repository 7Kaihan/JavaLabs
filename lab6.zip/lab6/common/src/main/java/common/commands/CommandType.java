package common.commands;

/**
 * command types
 */
public enum CommandType {
    NORMAL,
    CLIENT_ONLY,
    SERVER_ONLY
}
