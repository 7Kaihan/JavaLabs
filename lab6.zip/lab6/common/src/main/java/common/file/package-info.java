/**
 * package for operating with files
 */
package common.file;