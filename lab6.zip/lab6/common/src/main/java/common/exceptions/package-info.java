/**
 * package with different kinds of common.exceptions
 * @see common.exceptions.InvalidDataException
 * @see common.exceptions.CommandException
 * @see common.exceptions.FileException
 */
package common.exceptions;