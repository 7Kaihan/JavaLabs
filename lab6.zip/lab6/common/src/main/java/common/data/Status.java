package common.data;
public enum Status {
    RECOMMENDED_FOR_PROMOTION,
    REGULAR,
    PROBATION;
}
