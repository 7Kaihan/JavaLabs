package common.data;

public class RawWorker {
    
}
