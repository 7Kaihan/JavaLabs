package common.data;
public enum Position {
    DIRECTOR,
    MANAGER,
    ENGINEER,
    BAKER;
}
