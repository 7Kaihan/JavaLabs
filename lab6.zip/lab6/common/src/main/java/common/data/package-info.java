/**
 * package with storable common.data
 */
package common.data;