/**
 * package with some useful common.utils
 */
package common.utils;