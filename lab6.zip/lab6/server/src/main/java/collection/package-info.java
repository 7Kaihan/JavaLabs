/**
 * package for operating with collections
 */
package collection;