package json;

public class FlatSerializer {
    private CollectionManager collection;
    public FlatSerializer(CollectionManager collection){
        this.collection = collection;
    }
    public String xmlSerialize(){
        XStream xstream = new XStream();
        return  xstream.toXML(collection.getCollection());
    }
}
