package org.modules;

public interface DataValidator {
    boolean valid ();
}
