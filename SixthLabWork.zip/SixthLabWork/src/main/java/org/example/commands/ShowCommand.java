package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.collection.CollectionManager;
import org.example.exceptions.CommandException;
import org.example.exceptions.ConnectionException;
import org.example.exceptions.EmptyCollectionException;
import org.example.exceptions.FileException;
import org.example.modules.StudyGroup;

import java.util.stream.Collectors;

public class ShowCommand extends CommandImplementation{
    private CollectionManager<StudyGroup> collectionManager;
    public ShowCommand(CollectionManager<StudyGroup>collectionManager){
        super("show",CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        if(collectionManager.getCollection().isEmpty())throw new EmptyCollectionException("collection is empty");
        return collectionManager.getCollection().stream().map(StudyGroup::toString).collect(Collectors.joining("\n"));
    }
}
