package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.collection.CollectionManager;
import org.example.exceptions.CommandException;
import org.example.exceptions.ConnectionException;
import org.example.exceptions.FileException;
import org.example.modules.StudyGroup;

public class AddCommand extends CommandImplementation{
    private CollectionManager<StudyGroup>collectionManager;
    public AddCommand(CollectionManager<StudyGroup>collectionManager){
        super("add",CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }
    public CollectionManager<StudyGroup> getManager (){
        return collectionManager;
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        getManager().add(getStudyGroupArg());
        return "Added element: "+getStudyGroupArg().toString();
    }
}
