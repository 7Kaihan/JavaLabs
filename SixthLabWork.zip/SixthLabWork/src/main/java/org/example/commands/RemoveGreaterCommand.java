package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.collection.CollectionManager;
import org.example.exceptions.*;
import org.example.modules.StudyGroup;

public class RemoveGreaterCommand extends CommandImplementation{
    private CollectionManager<StudyGroup>collectionManager;
    public RemoveGreaterCommand(CollectionManager<StudyGroup> collectionManager){
        super("remove_greater",CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        if(collectionManager.getCollection().isEmpty())throw new EmptyCollectionException("collection is empty");
        if(!hasStudyGroupArg()) throw new MissedCommandArgumentException();
        try {
            collectionManager.removeGreater(getStudyGroupArg());
            return "all elements greater than the given has been removed";
        }catch (org.example.exceptions.InvalidDataException e) {
            throw new CommandException("can't execute the command");
        }
    }
}
