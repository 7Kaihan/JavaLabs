package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.collection.CollectionManager;
import org.example.exceptions.*;
import org.example.modules.StudyGroup;

import static org.example.parser.Parser.parseId;

public class RemoveByIdCommand extends CommandImplementation{
    private CollectionManager<StudyGroup>collectionManager;
    public RemoveByIdCommand(CollectionManager<StudyGroup>collectionManager){
        super("remove_by_id",CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        if(collectionManager.getCollection().isEmpty()) throw new EmptyCollectionException("collection is empty");
        if(!hasStringArg())throw new MissedCommandArgumentException();
        try {
            Integer id = parseId(getStringArg());
            if(!collectionManager.getUniqueIds().contains(id))throw new InvalidCommandArgumentException("no such id ");
            boolean success = collectionManager.removeById(id);
            if(success) return "element #"+id+"has been removed from the collection";
            else throw new CommandException("can't update");
        }catch (org.example.exceptions.InvalidNumberException exception){
            throw new InvalidCommandArgumentException("Invalid id");
        }catch (org.example.exceptions.InvalidDataException  exception){
            throw new CommandException("can't update element ");
        }
    }
}
