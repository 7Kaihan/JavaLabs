package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.collection.CollectionManager;
import org.example.exceptions.CommandException;
import org.example.exceptions.ConnectionException;
import org.example.exceptions.EmptyCollectionException;
import org.example.exceptions.FileException;
import org.example.modules.StudyGroup;

public class PrintUniqueFormOfEducationCommand extends CommandImplementation{
    private CollectionManager<StudyGroup> collectionManager;
    public PrintUniqueFormOfEducationCommand(CollectionManager<StudyGroup>collectionManager){
        super("print_unique_form_of_education",CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        if(collectionManager.getCollection().isEmpty())throw new EmptyCollectionException("collection is empty");
        if(collectionManager.uniqueFormOfEducation().isEmpty())throw new CommandException("no unique form of education found ");
        return collectionManager.uniqueFormOfEducation().toString();
    }
}
