package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.collection.CollectionManager;
import org.example.exceptions.CommandException;
import org.example.exceptions.ConnectionException;
import org.example.exceptions.FileException;
import org.example.modules.StudyGroup;

public class AddIfMax extends CommandImplementation{
    private CollectionManager<StudyGroup> collectionManager;
    public AddIfMax(CollectionManager<StudyGroup> collectionManager){
        super("add_if_max",CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        boolean success;
        try {
            success = collectionManager.addIfMax(getStudyGroupArg());
            if(success) return ("Added element : "+getStudyGroupArg().toString());
            else throw new CommandException("can't be added");
        }catch (org.example.exceptions.InvalidDataException exception){
            throw new InvalidDataException("unsuccessful");
        }
    }
}
