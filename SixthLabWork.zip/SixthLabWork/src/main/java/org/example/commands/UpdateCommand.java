package org.example.commands;


import com.sun.media.sound.InvalidDataException;
import org.example.collection.CollectionManager;
import org.example.exceptions.*;
import org.example.modules.StudyGroup;
import static org.example.parser.Parser.parseId;
public class UpdateCommand extends CommandImplementation {
    private CollectionManager<StudyGroup>collectionManager;
    public UpdateCommand(CollectionManager<StudyGroup>collectionManager){
        super("update",CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        if(collectionManager.getCollection().isEmpty())throw new EmptyCollectionException("collection is empty");
        if(!hasStringArg() || !hasStudyGroupArg())throw new MissedCommandArgumentException();
        try {
            Integer id = parseId(getStringArg());
            if(!collectionManager.getUniqueIds().contains(id))throw new InvalidCommandArgumentException("no such id");
            boolean success = collectionManager.update(id,getStudyGroupArg());
            if(success) return "element #"+id + " has been updated!!";
            else throw new CommandException("can't update");
        }catch (InvalidNumberException  exception){
            throw new InvalidCommandArgumentException("can't parse id");
        }catch (org.example.exceptions.InvalidDataException exception){
            throw new CommandException("can't update the object");
        }
    }
}
