package org.example.commands;public class ExecuteScriptCommand {
}
