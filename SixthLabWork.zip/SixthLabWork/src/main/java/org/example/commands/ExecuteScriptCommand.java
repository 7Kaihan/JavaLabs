package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.exceptions.*;

public class ExecuteScriptCommand extends CommandImplementation{
    ServerCommandManager commandManager;
    public ExecuteScriptCommand(ServerCommandManager commandManager){
        super("execute_script",CommandType.NORMAL);
        this.commandManager = commandManager;
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        if(!hasStringArg())throw new MissedCommandArgumentException();
        if(commandManager.getStack().contains(getStringArg()))throw new RecursiveScriptExecuteException();
        commandManager.getStack().add(getStringArg());
        ServerCommandManager process = new ServerCommandManager(commandManager.getServer());
        process.fileMode(getStringArg());

        commandManager.getStack().pop();
        return "script successfully executed";
    }
}
