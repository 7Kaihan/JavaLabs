package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.collection.CollectionManager;
import org.example.exceptions.CommandException;
import org.example.exceptions.ConnectionException;
import org.example.exceptions.FileException;
import org.example.modules.StudyGroup;

public class HelpCommand extends CommandImplementation{
    public HelpCommand(){
        super("help",CommandType.NORMAL);
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        return CommandManager.getHelp();
    }
}
