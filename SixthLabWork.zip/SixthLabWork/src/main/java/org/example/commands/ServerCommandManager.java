package org.example.commands;

import org.example.Server.Server;
import org.example.collection.CollectionManager;
import org.example.connection.Request;
import org.example.connection.Response;
import org.example.file.FileManager;
import org.example.modules.StudyGroup;

public class ServerCommandManager extends CommandManager{
    private Server server;
    private CollectionManager<StudyGroup>collectionManager;
    private FileManager fileManager;
    public ServerCommandManager(Server server){
        this.server = server;
        collectionManager = server.getCollectionManager();
        addCommand(new ExitCommand());
        addCommand(new HelpCommand());
        addCommand(new InfoCommand(collectionManager));
        addCommand(new AddCommand(collectionManager));
        addCommand(new AddIfMax(collectionManager));
        addCommand(new ExecuteScriptCommand(this));
        addCommand(new UpdateCommand(collectionManager));
        addCommand(new RemoveByIdCommand(collectionManager));
        addCommand(new SaveCommand(collectionManager,fileManager));
        addCommand(new ShowCommand(collectionManager));
    }
    @Override
    public Response runCommand(Request req) {
        return null;
    }
}
