package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.collection.CollectionManager;
import org.example.exceptions.*;
import org.example.modules.StudyGroup;

public class HeadCommand extends CommandImplementation{
    private CollectionManager<StudyGroup> collectionManager;
    public HeadCommand(CollectionManager<StudyGroup>collectionManager){
        super("head",CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        if(collectionManager.getCollection().isEmpty())throw new EmptyCollectionException("collection is empty");
        return collectionManager.collectionHead().toString();
    }
}
