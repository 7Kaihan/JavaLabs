package org.example.commands;public class ExitCommand {
}
