package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.exceptions.CommandException;
import org.example.exceptions.ConnectionException;
import org.example.exceptions.ExitException;
import org.example.exceptions.FileException;

public class ExitCommand extends CommandImplementation{
    public ExitCommand(){
        super("exit",CommandType.NORMAL);
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        throw new ExitException();
    }
}
