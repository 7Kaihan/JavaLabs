package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.collection.CollectionManager;
import org.example.exceptions.*;
import org.example.modules.StudyGroup;
import static org.example.parser.Parser.parseExpelledStudents;
public class CountByExpelledStudents extends CommandImplementation{
    private CollectionManager<StudyGroup> collectionManager;
    public CountByExpelledStudents(CollectionManager<StudyGroup>collectionManager){
        super("count_by_expelled_students",CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }
    @Override
    public String execute() throws InvalidDataException, CommandException, FileException, ConnectionException {
        if(collectionManager.getCollection().isEmpty())throw new EmptyCollectionException("collection is empty");
        if(!hasStringArg())throw new MissedCommandArgumentException();
        try{
            long expelledStudents = parseExpelledStudents(getStringArg());
            try {
                collectionManager.countByExpelledStudents(expelledStudents);
                return Long.toString(expelledStudents);
            }catch (org.example.exceptions.InvalidDataException exception){
                throw new InvalidCommandArgumentException("the passed expelled student is not valid");
            }
        }catch (InvalidNumberException exception) {
            throw new CommandException(exception.getMessage());
        }
    }
}
