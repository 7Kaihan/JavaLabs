package org.example.parser;

import org.example.exceptions.InvalidNumberException;

public class Parser {
    public static int parseId(String id) throws InvalidNumberException {
        try{
            return Integer.parseInt(id);
        }catch (NumberFormatException exception){
            throw new InvalidNumberException();
        }
    }
    public static long parseExpelledStudents(String expelledStudents)throws InvalidNumberException{
        try{
            return Long.parseLong(expelledStudents);
        }catch (NumberFormatException exception){
            throw new InvalidNumberException();
        }
    }
}
