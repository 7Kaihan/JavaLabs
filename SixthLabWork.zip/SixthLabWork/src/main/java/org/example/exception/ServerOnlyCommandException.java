package org.example.exception;

import org.example.exceptions.CommandException;

public class ServerOnlyCommandException extends CommandException{
    public ServerOnlyCommandException(String message) {
        super(message);
    }
}
