package org.example.Server;

import org.example.collection.CollectionManager;
import org.example.collection.StudyGroupCollectionManager;
import org.example.commands.ServerCommandManager;
import org.example.connection.Request;
import org.example.connection.Response;
import org.example.exceptions.*;
import org.example.file.FileManager;
import org.example.modules.StudyGroup;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.AlreadyBoundException;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
public class Server extends Thread implements Closeable {
    private CollectionManager<StudyGroup>collectionManager;
    private ServerSocketChannel channel;
    private FileManager fileManager;
    private int port;
    private InetSocketAddress clientAddress;
    private volatile boolean running;
    private ServerCommandManager commandManager;
    private void init(int p,String path)throws ConnectionException{
        running = true;
        port = p;
        collectionManager = new StudyGroupCollectionManager();
        fileManager = new FileManager();
        commandManager = new ServerCommandManager(this);
        try {
            collectionManager.deserialize(fileManager.read());
       }catch (FileException exception){
            //Log.logger.error(exception.getMessage());
        }
        host(port);
        setName("server thread");
        //Log.logger.trace("starting server");
    }
    private void host(int port)throws ConnectionException{
        try{
            if(channel!=null && channel.isOpen()) channel.close();
            channel = ServerSocketChannel.open();
            channel.bind(new InetSocketAddress(port));
        }catch (AlreadyBoundException exception){
            throw new PortAlreadyInUseException();
        }catch (IllegalArgumentException exception){
            throw new InvalidPortException();
        }catch (IOException exception){
            throw new ConnectionException("something went wrong during server initialization");
        }
    }
    public Server(int port,String path)throws ConnectionException{
        init(port,path);
    }

    public Request receive () throws ConnectionException, InvalidDataException{
        ByteBuffer buffer = ByteBuffer.allocate(4098);
        try{
            clientAddress = (InetSocketAddress) channel.getLocalAddress();
            //Log.logger.trace("received request from "+ clientAddress.toString());
        }catch (ClosedChannelException exception){
            throw new ClosedConnectionException();
        }catch (IOException exception){
            throw new ConnectionException("something went wrong during receiving request");
        }
        try{
            ObjectInputStream inputStream = new ObjectInputStream(new ByteArrayInputStream(buffer.array()));
            Request req = (Request) inputStream.readObject();
            return req;
        }catch (IOException | ClassNotFoundException exception){
            throw new InvalidReceivedDataException();
        }

    }
    public void send(Response response)throws ConnectionException{
        if(clientAddress == null)throw new InvalidAddressException("no client address found");
        try{
           SocketChannel socketChannel = SocketChannel.open();
            Socket socket = socketChannel.socket();
            ObjectOutputStream objectOutputStream =
        }
    }
    @Override
    public void run(){

    }
    @Override
    public void close() {

    }
}
