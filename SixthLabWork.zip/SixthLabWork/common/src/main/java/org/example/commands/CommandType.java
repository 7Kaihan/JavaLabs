package org.example.commands;

public enum CommandType {
    CLIENT,
    SERVER,
    NORMAL;
}
