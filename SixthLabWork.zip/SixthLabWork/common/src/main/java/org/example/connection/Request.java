package org.example.connection;

import org.example.modules.StudyGroup;

import java.io.Serializable;

public interface Request extends Serializable {
    String getStringArg();
    StudyGroup getStudyGroup();
    String getCommandName();
}
