package org.example.commands;

import com.sun.media.sound.InvalidDataException;
import org.example.connection.AnswerMsg;
import org.example.connection.Request;
import org.example.connection.Response;
import org.example.connection.Status;
import org.example.exceptions.CommandException;
import org.example.exceptions.ConnectionException;
import org.example.exceptions.ExitException;
import org.example.exceptions.FileException;
import org.example.modules.StudyGroup;

public abstract class CommandImplementation implements Command{
    private CommandType type;
    private String name;
    private Request arg;
    public CommandImplementation(String n,CommandType t){
        name = n ;
        type = t;
    }
    @Override
    public String getName() {
        return name;
    }

    @Override
    public CommandType getType() {
        return type;
    }

    public abstract String execute()throws InvalidDataException, CommandException, FileException, ConnectionException;
    @Override
    public Response run() {
        AnswerMsg res = new AnswerMsg();
        try{
            res.info(execute());
        }catch (ExitException e){
            res.info(e.getMessage());
            res.setStatus(Status.EXIT);
        }catch (InvalidDataException | CommandException | FileException | ConnectionException e){
            res.error(e.getMessage());
        }
        return res;
    }

    @Override
    public void setArgument(Request req) {
        arg = req;
    }
    public Request getArgument(){
        return arg;
    }
    public boolean hasStringArg(){
        return arg!=null && arg.getStringArg()!=null && !arg.getStringArg().equals("");
    }
    public boolean hasStudyGroupArg(){
        return arg!=null && arg.getStudyGroup()!=null;
    }

    public String getStringArg(){
        return getArgument().getStringArg();
    }
    public StudyGroup getStudyGroupArg(){
        return getArgument().getStudyGroup();
    }
}
