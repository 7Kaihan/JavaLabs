package org.example.modules;

import java.io.Serializable;

public enum Color implements Serializable {
    GREEN,
    RED,
    BLACK,
    WHITE;
}
