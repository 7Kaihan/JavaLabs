package org.example.commands;

import org.example.exceptions.FileException;
import org.example.exceptions.NoSuchCommandException;
import org.example.input.ConsoleInputManager;
import org.example.input.FileInputManager;
import org.example.input.InputManager;
import org.example.connection.*;
import java.io.Closeable;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public abstract class CommandManager implements Closeable {
    private Map<String,Command> map;
    private InputManager inputManager;
    private boolean isRunning;
    private String currentScriptFileName;
    private static Stack<String> callStack = new Stack<>();
    public Stack<String> getCallStack (){
        return callStack;
    }
    public CommandManager(){
        isRunning = false;
        currentScriptFileName = "";
        map = new HashMap<>();
    }
    public void addCommand(Command c){
        map.put(c.getName(),c);
    }
    public void addCommand(String name,Command c){
        map.put(name,c);
    }
    public Command getCommand(String s){
        if ( ! hasCommand(s) )throw new NoSuchCommandException();
        Command cmd = map.get(s);
        return cmd;
    }
    public boolean hasCommand(String s){
        return map.containsKey(s);
    }
    public abstract Response runCommand(Request req);

    public void consoleMode(){
        inputManager = new ConsoleInputManager();
        isRunning = true;
        while(isRunning){
            System.out.println("Enter a command (help to get command list ) : ");
            CommandMsg  commandMsg = inputManager.readCommand();
            Response answerMsg = runCommand(commandMsg);
            if(answerMsg.getStatus() == Status.EXIT) {
                close();
            }
        }
    }
    public void fileMode(String path)throws FileException {
        currentScriptFileName = path;
        inputManager = new FileInputManager(path);
        isRunning = true;
        while(isRunning && inputManager.getScanner().hasNextLine()){
            CommandMsg commandMsg = inputManager.readCommand();
            Response answerMsg = runCommand(commandMsg);
            if(answerMsg.getStatus() == Status.EXIT){
                close();
            }
        }
    }
    public static String getHelp(){
        return "commands";
    }
    public void setRunning(boolean running){
        isRunning = running;
    }
    @Override
    public void close(){
        setRunning(false);
    }
}
