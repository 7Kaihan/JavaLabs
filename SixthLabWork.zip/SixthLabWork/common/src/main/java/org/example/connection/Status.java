package org.example.connection;

public enum Status {
    ERROR,
    FINE,
    EXIT;
}
