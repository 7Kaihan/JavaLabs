package org.example.exceptions;

/**
 * thrown when port is invalid
 */
public class InvalidPortException extends ConnectionException {
    public InvalidPortException(){
        super("invalid port");
    }
}
