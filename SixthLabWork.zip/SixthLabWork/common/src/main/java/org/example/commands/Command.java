package org.example.commands;
import org.example.connection.*;
public interface Command {
    Response run();
    String getName();
    CommandType getType();
    void setArgument(Request a);
}
