package org.example.modules;

public interface DataValidator {
    boolean valid ();
}
