package org.example;

import org.example.server.Server;

import java.io.IOException;

public class Main {
    private static String PORT = System.getenv("port");
    private static String PATH = System.getenv("path");
    public static void main(String[] args) {
        int port =0;
        String path = "file.csv";
        try {
            if (PATH.equals("") || PORT.equals(""))
                throw new RuntimeException("Invalid port or path");
            try {
                port = Integer.parseInt(PORT);
            } catch (NumberFormatException exception) {
                System.err.println("Invalid port");
            }
            path = PATH;
            Server server = new Server(port,path);
            server.start();
            server.consoleMode();
        }catch (Exception exception){
            exception.printStackTrace();
        }
    }
}