package org.example.commands;

import org.example.collection.CollectionManager;
import org.example.file.ReaderWriter;
import org.example.models.Student;

public class SaveCommand extends CommandImplementation {
    private ReaderWriter fileManager;
    private CollectionManager<Student> collectionManager;
    public SaveCommand(CollectionManager<Student> collectionManager,ReaderWriter fileManager) {
        super("save",CommandType.SERVER);
        this.collectionManager = collectionManager;
        this.fileManager = fileManager;
    }

    @Override
    public String execute() {
        if(hasStringArg())
            fileManager.setPath(getStringArg());
        fileManager.write(collectionManager.serializeCollection());
        return "collection successfully saved";
    }
}
