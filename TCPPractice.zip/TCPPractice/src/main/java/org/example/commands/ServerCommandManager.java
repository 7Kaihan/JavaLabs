package org.example.commands;

import org.example.Request.Request;
import org.example.Response.AnswerMsg;
import org.example.Response.Response;
import org.example.collection.CollectionManager;
import org.example.file.ReaderWriter;
import org.example.models.Student;
import org.example.server.Server;

public class ServerCommandManager extends CommandManager{
    private Server server;
    private CollectionManager<Student> collectionManager;
    private ReaderWriter fileManager;
    public ServerCommandManager(Server server){
        this.server = server;
        collectionManager = server.getCollectionManager();
        fileManager = server.getFileManager();
        addCommand(new ExitCommand());
        addCommand(new AddCommand(collectionManager));
        addCommand(new RemoveByIDCommand(collectionManager));
        addCommand(new SaveCommand(collectionManager,fileManager));
        addCommand(new Update(collectionManager));
    }
    public Server getServer(){
        return server;
    }
    @Override
    public AnswerMsg runCommand(Request request) {
        AnswerMsg res = new AnswerMsg();
        try {
           Command command = getCommand(request.getCommand());
           command.setArgument(request);
           res = (AnswerMsg) command.run();
        }catch (RuntimeException exception){
            System.err.println("server run command error");
        }
        return res;
    }

}
