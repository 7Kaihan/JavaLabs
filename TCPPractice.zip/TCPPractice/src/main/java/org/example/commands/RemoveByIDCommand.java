package org.example.commands;

import org.example.collection.CollectionManager;
import org.example.models.Student;

public class RemoveByIDCommand extends CommandImplementation{
    private CollectionManager<Student>collectionManager;
    public RemoveByIDCommand(CollectionManager<Student>collectionManager) {
        super("remove_by_id", CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }

    @Override
    public String execute() {
        if(collectionManager.getCollection().isEmpty())throw new RuntimeException("collection is empty");
        if(!hasStringArg())throw new RuntimeException("no argument found");
        int id = 0;
        boolean success = false;
        try{
             id = Integer.parseInt(getStringArg());
            if(!collectionManager.checkId(id))throw new RuntimeException("no such id");
            success = collectionManager.removeById(id);

        }catch (NumberFormatException exception){
            System.out.println("id is not valid");
        }
        if(success) return "element #"+id+" has been removed";
        else throw new RuntimeException("unsuccessful");
    }
}
