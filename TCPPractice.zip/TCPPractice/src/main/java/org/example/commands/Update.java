package org.example.commands;

import org.example.collection.CollectionManager;
import org.example.models.Student;

public class Update extends CommandImplementation{
    private CollectionManager<Student> collectionManager;
    public Update(CollectionManager<Student>collectionManager) {
        super("update", CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }
    @Override
    public String execute() {
       if(collectionManager.getCollection().isEmpty())throw new RuntimeException("Collection is empty");
       if(!hasStringArg() || !hasStudentArg() )throw new RuntimeException("arguments are missing");
       try{
           Integer id  = Integer.parseInt(getStringArg());
           if(!collectionManager.checkId(id))throw new RuntimeException("no such id");
           boolean success = collectionManager.update(id,getStudentArg());
           if(success)return "element #"+id+" has been updated!!!";
           else throw new RuntimeException("can't update element");
       }catch (NumberFormatException exception){
           throw new RuntimeException("invalid Id");
       }
    }
}
