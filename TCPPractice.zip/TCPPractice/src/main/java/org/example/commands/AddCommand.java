package org.example.commands;

import org.example.collection.CollectionManager;
import org.example.models.Student;

public class AddCommand extends CommandImplementation{
    private CollectionManager<Student> collectionManager;
    public AddCommand(CollectionManager<Student>collectionManager){
        super("add",CommandType.NORMAL);
        this.collectionManager = collectionManager;
    }
    public CollectionManager<Student> getCollectionManager() {
        return collectionManager;
    }
    @Override
    public String execute() {
        getCollectionManager().add(getStudentArg());
        return "Added element : "+ getStudentArg().toString();
    }
}
