package org.example.commands;

public class ExitCommand extends CommandImplementation{
    public ExitCommand() {
        super("exit",CommandType.NORMAL);
    }

    @Override
    public String execute() {
        throw new RuntimeException("shutting down");
    }
}
