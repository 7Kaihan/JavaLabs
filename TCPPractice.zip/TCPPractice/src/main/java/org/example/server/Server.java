package org.example.server;

import org.example.Request.Request;
import org.example.Response.AnswerMsg;
import org.example.Response.Response;
import org.example.Response.Status;
import org.example.collection.CollectionManager;
import org.example.collection.StudentCollectionManager;
import org.example.commands.CommandManager;
import org.example.commands.CommandType;
import org.example.commands.ServerCommandManager;
import org.example.file.FileManager;
import org.example.file.ReaderWriter;
import org.example.models.Student;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AlreadyBoundException;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SocketChannel;

public class Server extends Thread {
    private CollectionManager<Student> collectionManager;
    private ReaderWriter fileManager;
    private ServerCommandManager commandManager;
    private int port;
    private InetSocketAddress clientAddress;
    private SocketChannel channel;
    private volatile boolean running;
    private String path;
    private void inti (int p,String path){
        running = true;
        this.path = path;
        port = p;
        fileManager = new FileManager(path);
        collectionManager = new StudentCollectionManager();
        commandManager = new ServerCommandManager(this);
        try {
            collectionManager.deserializeCollection(fileManager.read());
        }catch (RuntimeException exception){
            System.err.println(exception.getMessage());
        }
        host(port);
        setName("server thread");
    }
    private void host(int port){
        try{
            if (channel !=null && channel.isOpen())channel.close();
            channel = SocketChannel.open();
            channel.bind(new InetSocketAddress(port) );
        }catch (AlreadyBoundException exception){
            System.err.println("port exception");
        }catch (IllegalArgumentException exception){
            System.err.println("Illegal argument exception");
        }catch (IOException exception){
            System.err.println("connection exception");
        }
    }
    public Server(int p,String path)throws Exception{
        inti(p,path);
    }
    public Request receive ()throws Exception{
        ByteBuffer buf = ByteBuffer.allocate(4098);
        try{
           clientAddress = (InetSocketAddress) channel.getRemoteAddress();
        }catch (ClosedChannelException exception){
            System.err.println("channel is closed");
        }catch (IOException exception){
            System.err.println("something went wrong");
        }
        try{
            ObjectInputStream objectInputStream = new ObjectInputStream(new ByteArrayInputStream(buf.array()));
            Request request = (Request) objectInputStream.readObject();
            return request;
        }catch (ClassNotFoundException | ClassCastException | IOException exception){
            throw new RuntimeException("something went wrong while receiving");
        }
    }
    public void send (Response response)throws Exception{
        if(clientAddress == null )throw new RuntimeException("no client address found");
        try{
            ObjectOutputStream outputStream = new ObjectOutputStream(
                    channel.socket().getOutputStream()
            );
            outputStream.writeObject(response);
            outputStream.flush();
        }catch (IOException exception){
            System.err.println("something went wrong during object transmission");
        }
    }
    @Override
    public void run(){
        while(running){
            AnswerMsg answerMsg = new AnswerMsg();
            try {
                try {
                    Request commandMsg = receive();
                    if (commandManager.getCommand(commandMsg).getType() == CommandType.SERVER)
                        throw new RuntimeException("this command is only for server");
                    answerMsg = commandManager.runCommand(commandMsg);
                    if(answerMsg.getStatus() == Status.EXIT){
                        close();
                    }
                } catch (Exception exception) {
                    answerMsg.error(exception.getMessage());
                }
                send(answerMsg);
            }catch (Exception exception){
                System.out.println("something went wrong answer message");
            }
        }
    }
    public void consoleMode(){
        commandManager.consoleMode();
    }
    public void close(){
        try{
            running = false;
            channel.close();
        }catch (IOException exception){
            System.err.println("can't close channel");
        }
    }
    public CommandManager getCommandManager(){
        return commandManager;
    }
    public ReaderWriter getFileManager(){
        return fileManager;
    }
    public CollectionManager<Student> getCollectionManager(){
        return collectionManager;
    }
}
