package org.example.collection;

import org.example.byteStream.deserialize.CollectionDeserializer;
import org.example.byteStream.serialize.CollectionSerializer;
import org.example.models.Student;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Optional;
import java.util.PriorityQueue;

public class StudentCollectionManager implements CollectionManager<Student>{
    private PriorityQueue<Student>collection;
    private HashSet<Integer> ids;
    public StudentCollectionManager(){
        collection = new PriorityQueue<>();
        ids = new HashSet<>();
    }

    public void setIds(HashSet<Integer> ids) {
        this.ids = ids;
    }

    public HashSet<Integer> getIds() {
        return ids;
    }

    @Override
    public int autoId() {
        if(ids.isEmpty())
        {
            return 1;
        }else{
            Integer lastId = getLast().getId();
            if(ids.contains(lastId))
                while(ids.contains(lastId))
                    lastId +=1;
            ids.add(lastId);
            return lastId;
        }
    }

    @Override
    public void sort() {
    }

    @Override
    public boolean checkId(Integer id) {
        return ids.contains(id);
    }

    @Override
    public PriorityQueue<Student> getCollection() {
        return collection;
    }

    @Override
    public void add(Student element) {
        element.setId(autoId());
        collection.add(element);
        System.out.println("added element to the collection : ");
        System.out.println(element);
    }

    @Override
    public String getInfo() {
        return "PriorityQueue of Student - Size : "+collection.size();
    }

    @Override
    public boolean removeById(int id) {
        return collection.removeIf(student -> student.getId() == id);
    }

    @Override
    public boolean update(int id, Student element) {
        Optional<Student> student = collection.stream()
                .filter(student1 -> student1.getId() == id)
                .findFirst();
        if(student.isPresent()){
            collection.remove(student.get());
            element.setId(id);
            collection.add(element);
            return true;
        }
        return false;
    }

    @Override
    public String serializeCollection() {
        if(collection.isEmpty())throw new RuntimeException("Collection is empty");
        return new CollectionSerializer(this).builder();
    }

    @Override
    public boolean deserializeCollection(String csv) {
        boolean success = true;
        CollectionDeserializer collectionDeserializer = new CollectionDeserializer(this);
        if(collectionDeserializer.deserialize(csv).isEmpty()){
            success = false;
            throw new RuntimeException("Invalid csv");
        }
        else collection = collectionDeserializer.deserialize(csv) ;
        return success;
    }
    private Student getLast(){
        Object [] queue  = collection.toArray();
        Student last = (Student)queue[0];
        Comparator<Student> comparator = (Comparator<Student>) collection.comparator();
        if(comparator != null)
            for(int i =1 ; i<collection.size() ; i++)
                if(comparator.compare(last,(Student) queue[i])<0)
                    last = (Student) queue[i];
        else
            for(int j=1 ; j < collection.size();j++)
                if(((Comparable)last).compareTo(((Comparable)queue[j]))<0)
                    last = (Student)queue[j];
        return last;
    }
}
