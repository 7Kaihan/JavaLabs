package org.example.collection;

import org.example.models.Student;

import java.util.HashSet;
import java.util.PriorityQueue;

public interface CollectionManager<T>{
    int autoId();
    void sort();
    boolean checkId(Integer id);
    void setIds(HashSet<Integer> ids);
    PriorityQueue<T> getCollection();
    void add(T element);
    String getInfo();
    boolean removeById(int id);
    boolean update(int id, T element);
    String serializeCollection();
    boolean deserializeCollection(String csv);

}
