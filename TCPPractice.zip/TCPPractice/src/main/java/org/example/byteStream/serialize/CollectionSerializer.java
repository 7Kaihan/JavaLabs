package org.example.byteStream.serialize;

import org.example.collection.CollectionManager;
import org.example.models.Student;

import java.util.concurrent.atomic.AtomicReference;

public class CollectionSerializer {
    private CollectionManager<Student>collectionManager;
    private static String CSV_SPILITOR = ",";
    public CollectionSerializer(CollectionManager<Student>collectionManager){
        this.collectionManager = collectionManager;
    }
    public String builder(){
        AtomicReference<String>csv = new AtomicReference<>("");
        String column = "Id,Name,Age,GroupNumber,Coordinate x,Coordinate y,State";
        collectionManager.getCollection().forEach(student -> {
            StringBuffer oneLine = new StringBuffer("");
            oneLine.append(student.getId());
            oneLine.append(CSV_SPILITOR);
            oneLine.append(student.getStudentName());
            oneLine.append(CSV_SPILITOR);
            oneLine.append(student.getAge());
            oneLine.append(CSV_SPILITOR);
            oneLine.append(student.getGroupNumber() == null ? null:student.getGroupNumber());
            oneLine.append(CSV_SPILITOR);
            oneLine.append(student.getCoordinates().getX());
            oneLine.append(CSV_SPILITOR);
            oneLine.append(student.getCoordinates().getY());
            oneLine.append(CSV_SPILITOR);
            oneLine.append(student.getState() == null ? null : student.getState());
            oneLine.append("\n");
            csv.set(csv.get()+oneLine);
        });
        return column+csv.get();
    }
}
