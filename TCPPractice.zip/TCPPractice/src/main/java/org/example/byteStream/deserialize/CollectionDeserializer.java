package org.example.byteStream.deserialize;

import org.example.collection.CollectionManager;
import org.example.models.Coordinates;
import org.example.models.State;
import org.example.models.Student;

import java.util.*;

public class CollectionDeserializer {
    private Parser parser;
    private HashSet<Integer>ids;
    private PriorityQueue<Student>collection;
    private CollectionManager<Student>collectionManager;
    public CollectionDeserializer(CollectionManager<Student> collectionManager){
        this.collectionManager = collectionManager;
        ids = new HashSet<>();
        parser = new Parser();
        collection = new PriorityQueue<>();
    }
    public PriorityQueue<Student> deserialize(String csv){
        String [] objects = csv.split("\n");
        String [] withOutColumn = new String[objects.length-1];
        for(int i=1 ;i< objects.length ;i++){
            withOutColumn[i-1]= objects[i];
        }
        List<String> csvObjects = new ArrayList<>();
        for( int i=0 ; i< withOutColumn.length ; i++){
            if(!withOutColumn[i].equals(""))
                csvObjects.add(withOutColumn[i]);
        }
        for(String object : csvObjects){
            try{
                Student student = parser.studentParse(object);
                ids .add(student.getId());
            }catch (Exception exception){
                System.err.println(exception.getMessage());
            }
        }
        collectionManager.setIds(ids);
        return collection;
    }
    private class Parser{
        Parser(){
        }
        public Student studentParse(String studentObject)throws Exception{
            List<String> csvObject = new ArrayList<>(Arrays.asList(studentObject.split(",")));
            int id;
            String name;
            int age;
            Integer groupNumber;
            int x;
            int y;
            Coordinates coordinates;
            State state;
            Student student;
            try{
                id = Integer.parseInt(csvObject.get(0));
            }catch (NumberFormatException exception){
                throw new Exception("Invalid id!!");
            }
            if(csvObject.get(1).equals(""))throw new Exception("Empty name !!");
            else name = csvObject.get(1);
            try{
                age = Integer.parseInt(csvObject.get(2));
            }catch (NumberFormatException exception){
                throw new Exception("Invalid age");
            }
            if(csvObject.get(3)==null)groupNumber = null;
            else {
                try {
                    groupNumber = Integer.parseInt(csvObject.get(3));
                } catch (NumberFormatException exception) {
                    throw new Exception("group number is not valid");
                }
            }
            try{
                x = Integer.parseInt(csvObject.get(4));
            }catch (NumberFormatException exception){
                throw new Exception("Invalid coordinate x");
            }
            try{
                y = Integer.parseInt(csvObject.get(5));
            }catch (NumberFormatException exception){
                throw new Exception ("Invalid coordinate y");
            }
            if(csvObject.get(6)==null) state = null;
            else{
                try{
                    state = State.valueOf(csvObject.get(6));
                }catch (IllegalArgumentException exception){
                    throw new Exception("Invalid student state");
                }
            }
            if(groupNumber == null){
                student = new Student(name,age,new Coordinates(x,y),state);
                student.setId(id);
            }
            if(state == null){
                student = new Student(name,age,groupNumber,new Coordinates(x,y));
                student.setId(id);
            }
            if(state == null && groupNumber == null){
                student = new Student(name,age,new Coordinates(x,y));
                student.setId(id);
            }
            else {
                student = new Student(name,age,groupNumber,new Coordinates(x,y),state);
                student.setId(id);
            }
            return student;
        }
    }
}
