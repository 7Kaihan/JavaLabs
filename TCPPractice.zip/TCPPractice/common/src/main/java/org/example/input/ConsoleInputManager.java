package org.example.input;

import org.example.models.State;

import java.util.Scanner;

public class ConsoleInputManager extends InputManagerImplementation{
    public ConsoleInputManager() {
        super(new Scanner(System.in));
        getScanner().useDelimiter("\n");
    }

    @Override
    public String readName() throws RuntimeException {
        return new Question<>("Enter name of the student : ",super::readName).getAnswer();
    }
    @Override
    public int readAge(){
        return new Question<>("Enter age of the student : ",super::readAge).getAnswer();
    }

    @Override
    public Integer readGroupNumber() throws RuntimeException {
        return new Question<>("Enter student 's groupNumber : ",super::readGroupNumber).getAnswer();
    }

    @Override
    public int readXCoordinate() throws RuntimeException {
        return new Question<>("Enter coordinate x : ",super::readXCoordinate).getAnswer();
    }
    @Override
    public int readYCoordinate(){
        return new Question<>("Enter coordinate y : ",super::readYCoordinate).getAnswer();
    }
    @Override
    public State readState(){
        return new Question<>("Enter State of the student (Lazy,Promising,Intelligent ) : ",super::readState).getAnswer();
    }

}
