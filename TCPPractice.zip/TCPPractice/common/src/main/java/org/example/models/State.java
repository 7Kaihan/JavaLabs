package org.example.models;

import java.io.Serializable;

public enum State implements Serializable {
    LAZY,
    PROMISING,
    INTELLIGENT;
}
