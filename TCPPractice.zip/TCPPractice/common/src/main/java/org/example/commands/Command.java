package org.example.commands;

import org.example.Request.Request;
import org.example.Response.Response;

public interface Command {
    Response run();
    String getName();
    CommandType getType();
    void setArgument(Request request);

}
