package org.example.Response;

public enum Status {
   ERROR,
    FINE,
    EXIT;
}
