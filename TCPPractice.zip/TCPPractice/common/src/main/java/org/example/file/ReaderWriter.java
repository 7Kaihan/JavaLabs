package org.example.file;

public interface ReaderWriter {
    void setPath(String path);
    String read();
    void write(String data);
}
