package org.example.input;

import org.example.Request.CommandMsg;
import org.example.models.Coordinates;
import org.example.models.State;
import org.example.models.Student;

import java.util.Scanner;

public interface InputManager {
    String readName()throws RuntimeException;
    int readAge()throws RuntimeException;
    State readState()throws RuntimeException;
    Integer readGroupNumber()throws RuntimeException;
    int readXCoordinate()throws RuntimeException;
    int readYCoordinate()throws RuntimeException;
    Coordinates readCoordinates();
    Student readStudent();
    CommandMsg readCommand();
    Scanner getScanner();
}
