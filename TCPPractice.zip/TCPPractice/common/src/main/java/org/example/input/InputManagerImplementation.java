package org.example.input;

import org.example.Request.CommandMsg;
import org.example.models.Coordinates;
import org.example.models.State;
import org.example.models.Student;

import java.util.Scanner;

public class InputManagerImplementation implements InputManager{
    private Scanner scanner;

    public InputManagerImplementation(Scanner scanner){
        this.scanner = scanner;
        scanner.useDelimiter("\n");
    }
    @Override
    public String readName() throws RuntimeException {
        String name = scanner.nextLine().trim();
        if(name.equals(""))
            throw new RuntimeException("name can't be empty");
        return name;
    }

    @Override
    public int readAge() throws RuntimeException {
        int age;
        try{
            String StringAge = scanner.nextLine().trim();
            age = Integer.parseInt(StringAge);
            if(age<18)throw new RuntimeException("can't be less than 18");
            return age;
        }catch (NumberFormatException exception){
            throw new RuntimeException("Invalid age!!!");
        }
    }

    @Override
    public State readState() throws RuntimeException {
        String state = scanner.nextLine().trim();
        if(state .equals(""))return null;
        else{
            try{
                return State.valueOf(state);
            }catch (IllegalArgumentException exception){
                throw new RuntimeException("Invalid state");
            }
        }
    }

    @Override
    public Integer readGroupNumber() throws RuntimeException {
        String group = scanner.nextLine().trim();
        if(group.equals(""))return null;
        else{
            try{
                return Integer.parseInt(group);
            }catch (NumberFormatException exception){
                throw new RuntimeException("Invalid groupNumber");
            }
        }
    }

    @Override
    public int readXCoordinate() throws RuntimeException {
        try{
            String xS = scanner.nextLine().trim();
            return Integer.parseInt(xS);
        }catch (NumberFormatException exception){
            throw new RuntimeException("Invalid coordinate x");
        }
    }

    @Override
    public int readYCoordinate() throws RuntimeException {
        try{
            String yS = scanner.nextLine().trim();
            return Integer.parseInt(yS);
        }catch (NumberFormatException exception){
            throw new RuntimeException("Invalid coordinate y");
        }
    }

    @Override
    public Coordinates readCoordinates() {
        return new Coordinates(readXCoordinate(),readYCoordinate());
    }

    @Override
    public Student readStudent() {
       if(readState() == null)
           return new Student(readName(),readAge(),readGroupNumber(),readCoordinates());
       if(readGroupNumber() == null)
           return new Student(readName(),readAge(),readCoordinates(),readState());
      else if(readGroupNumber() == null && readState() == null)
           return new Student(readName() ,readAge(),readCoordinates());
      return null;
    }

    @Override
    public CommandMsg readCommand() {
        String cmd = scanner.nextLine();
        String arg = null;
        Student student = null;
        if(cmd.contains(" ")){
            String arr[] = cmd.split(" ",2);
            cmd = arr [0];
            arg = arr [1];
        }
        if(cmd.equals("add") || cmd.equals("update")){
            try{
                student = readStudent();
            }catch (RuntimeException exception){

            }
        }
        return new CommandMsg(cmd,arg,student);
    }

    @Override
    public Scanner getScanner() {
        return scanner;
    }
}
