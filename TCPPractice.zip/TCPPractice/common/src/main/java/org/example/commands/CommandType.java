package org.example.commands;

public enum CommandType {
    SERVER,
    CLIENT,
    NORMAL;
}
