package org.example.Response;

public class AnswerMsg implements Response{
    private String msg;
    private Status status;
    public AnswerMsg(){
        msg ="";
        status = Status.FINE;
    }
    public AnswerMsg clear(){
        msg = "";
        return this;
    }
    public AnswerMsg info(Object str){
        msg = str.toString();
        return this;
    }
    public AnswerMsg error(Object str){
        msg = str.toString();
        setStatus(Status.ERROR);
        return this;
    }
    public AnswerMsg setStatus(Status status){
        this.status = status;
        return this;
    }
    @Override
    public String getMessage() {
        return msg;
    }
    public Status getStatus(){
        return status;
    }
}
