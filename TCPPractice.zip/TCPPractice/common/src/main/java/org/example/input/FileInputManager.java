package org.example.input;

import org.example.file.FileManager;

import java.util.Scanner;

public class FileInputManager extends InputManagerImplementation{
    public FileInputManager(String path){
        super(new Scanner(new FileManager(path).read()));
        getScanner().useDelimiter("\n");
    }
}
