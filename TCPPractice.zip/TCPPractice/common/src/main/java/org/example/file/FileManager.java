package org.example.file;

import java.io.*;

public class FileManager implements ReaderWriter {
    private InputStream inputStream;
    private String path;

    public FileManager(String path) {
        this.path = path;
    }

    @Override
    public void setPath(String path) {

    }

    @Override
    public String read() {
        String str = "";
        try {
            if (path == null) throw new RuntimeException("no path");
            InputStreamReader reader = null;
            File file = new File(path);
            if (!file.exists()) throw new RuntimeException("file doesn't exist");
            if (!file.canRead()) throw new RuntimeException("can read the file because file is restricted!!");
            inputStream = new FileInputStream(file);
            reader = new InputStreamReader(inputStream);
            int currentSymbol;
            while ((currentSymbol = reader.read()) != -1){
                str += ((char)currentSymbol);
            }
            reader.close();
        }catch (IOException exception){
            throw new RuntimeException("can't read the file");
        }
        return str;
    }
    public void create(File file){
        try {
            file.createNewFile();
        }catch (IOException exception){
            System.err.println("can't create the file");
        }
    }
    @Override
    public void write(String data) {
        try{
            if(path == null )throw new RuntimeException("path is null");
            File file = new File(path);

            if(!file.exists()){
                create(file);
            }
            if(!file.canWrite()) throw new RuntimeException("can't write in file");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(data);
            writer.close();
        }catch (IOException exception){
            System.err.println("can't access the file");
        }
    }
}
