package org.example.Request;

import org.example.models.Student;

import java.io.Serializable;

public interface Request extends Serializable {
    String getCommand();
    String getArgument();
    Student getStudent();
}
