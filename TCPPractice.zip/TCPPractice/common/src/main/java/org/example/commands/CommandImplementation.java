package org.example.commands;

import org.example.Request.Request;
import org.example.Response.AnswerMsg;
import org.example.Response.Response;
import org.example.models.Student;

public abstract class CommandImplementation implements Command{
    private CommandType type;
    private String name;
    private Request arg;
    public CommandImplementation(String n, CommandType t){
        name = n;
        type = t;
    }
    public CommandType getType(){
        return type;
    }
    public String getName(){
        return name;
    }


    public abstract String execute() throws Exception;

    /**
     * wraps execute into response
     * @return
     */
    public Response run(){
        AnswerMsg res = new AnswerMsg();
        try{
            res.info(execute());
        }
        catch(Exception e){
            res.info(e.getMessage());
        }
        return res;
    }
    public Request getArgument(){
        return arg;
    }
    public void setArgument(Request req){
        arg=req;
    }
    public boolean hasStringArg(){
        return arg!=null && arg.getArgument()!=null && !arg.getArgument().equals("");
    }
    public boolean hasStudentArg(){
        return arg!=null && arg.getStudent()!=null;
    }

    public String getStringArg(){
        return getArgument().getArgument();
    }

    public Student getStudentArg(){
        return getArgument().getStudent();
    }
}
