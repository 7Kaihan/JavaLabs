package org.example.commands;

import org.example.Request.CommandMsg;
import org.example.Response.Response;
import org.example.input.InputManager;
import java.io.Closeable;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import org.example.input.*;
public abstract class CommandManager implements  ForCommands, Closeable {
    private Map<String,Command> commandMap;
    private InputManager inputManager;
    private boolean isRunning;
    private String currentScriptFileName;
    private static Stack<String> callStack =  new Stack<>();
    public Stack<String> getCallStack(){
        return callStack;
    }
    public CommandManager(){
        isRunning = false;
        currentScriptFileName = "";
        commandMap = new HashMap<>();
    }
    public void addCommand(Command command){
        commandMap.put(command.getName(),command);
    }
    public void addCommand(String key,Command command){
        commandMap.put(key,command);
    }

    public Command getCommand(String s){
        if( ! hasCommand(s)) throw new RuntimeException("no such command");
        Command command = commandMap.get(s);
        return command;
    }
    public boolean hasCommand(String s){
        return commandMap.containsKey(s);
    }
    public void consoleMode(){
        inputManager = new ConsoleInputManager();
        isRunning = true;
        while(isRunning){
            System.out.println("Enter command (help to get command list) ");
            CommandMsg commandMsg = inputManager.readCommand();
        }
    }
    public void fileMode(String path){
        currentScriptFileName = path;
        inputManager = new FileInputManager(path);
        isRunning = true;
        while(isRunning && inputManager.getScanner().hasNextLine()){
            CommandMsg commandMsg = inputManager.readCommand();
            Response response = runCommand(commandMsg);
        }
    }
    public static String getHelp(){
        return "help : show help for available commands \n"+
                "add : adds new element to the collection \n"+
                "info : displays information regarding collection \n"+
                "update : updates element of the collection by the given id \n"+
                "remove_by_id : removes from the collection, element which has the given id \n"+
                "save : saves collection to the file";
    }
    public void setRunning(boolean running){
        isRunning = running;
    }
    public void close(){
        setRunning(false);
    }
}
