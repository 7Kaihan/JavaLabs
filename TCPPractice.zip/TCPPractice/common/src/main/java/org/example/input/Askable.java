package org.example.input;

public interface Askable<T> {
    T ask() throws RuntimeException;
}
