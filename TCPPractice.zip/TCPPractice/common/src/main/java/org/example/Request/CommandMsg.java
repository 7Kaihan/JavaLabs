package org.example.Request;

import org.example.models.Student;

import java.io.Serializable;

public class CommandMsg implements Request{
    private String command;
    private String argument;
    private Serializable object;
    public CommandMsg(String command,String argument,Serializable object){
        this.command = command;
        this.argument = argument;
        this.object = object;
    }
    @Override
    public String getCommand() {
        return command;
    }

    @Override
    public String getArgument() {
        return argument;
    }

    @Override
    public Student getStudent() {
        return (Student) object;
    }
}
