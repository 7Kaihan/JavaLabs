package org.example.commands;

import org.example.Request.Request;
import org.example.Response.Response;

public interface ForCommands {
    default void addCommand(String key,Command cmd){
        addCommand(key,cmd);
    }
    void addCommand(Command cmd);
    Response runCommand(Request request);
    Command getCommand(String key);
    default Command getCommand(Request request){
        return getCommand(request.getCommand());
    }
    boolean hasCommand(String s);
    default boolean hasCommand(Request request){
        return hasCommand(request.getCommand());
    }

    void consoleMode();
    void fileMode(String path);
}
