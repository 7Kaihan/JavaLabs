package org.example.Response;

import java.io.Serializable;

public interface Response extends Serializable {
    String getMessage();
    Status getStatus();
}
