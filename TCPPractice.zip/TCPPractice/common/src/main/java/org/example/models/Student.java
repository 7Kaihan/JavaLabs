package org.example.models;

import java.io.Serializable;

public class Student implements Serializable {
    private int id;
    private String studentName;
    private int age;
    private Integer groupNumber;
    private Coordinates coordinates;
    private State state;
    public Student(String studentName,int age,Coordinates coordinates){
        this.studentName = studentName;
        this.age = age;
        this.coordinates = coordinates;
    }
    public Student (String studentName,int age,int groupNumber,Coordinates coordinates){
        this.studentName = studentName;
        this.age = age;
        this.groupNumber = groupNumber;
        this.coordinates = coordinates;
    }
    public Student (String studentName,int age,Coordinates coordinates,State state){
        this.studentName = studentName;
        this.age = age;
        this.coordinates = coordinates;
        this.state = state;
    }
    public Student(String studentName,int age,int groupNumber,Coordinates coordinates,State state){
        this.studentName = studentName;
        this.age = age;
        this.groupNumber = groupNumber;
        this.coordinates = coordinates;
        this.state = state;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public Coordinates getCoordinates() {
        return coordinates;
    }

    public Integer getGroupNumber() {
        return groupNumber;
    }

    public State getState() {
        return state;
    }

    public String getStudentName() {
        return studentName;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentName='" + studentName + '\'' +
                ", age=" + age +
                ", groupNumber=" + groupNumber +
                ", coordinates=" + coordinates +
                ", state=" + state +
                '}';
    }
}
