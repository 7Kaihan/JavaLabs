package org.example.input;

public class Question<T> {
    private Askable<T>askable;
    private T answer;
    public Question(String msg, Askable<T> askable){
        this.askable = askable;
        while(true){
            try{
                System.out.println(msg+ " ");
                T answer = this.askable.ask();
                this.answer = answer;
                break;
            }catch (RuntimeException exception){
                System.err.println(exception.getMessage());
            }
        }
    }
    public T getAnswer(){
        return answer;
    }
}
