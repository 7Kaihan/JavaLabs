package org.example.commands;



import org.example.Request.Request;
import org.example.Response.AnswerMsg;
import org.example.client.Client;

public class ClientCommandManager extends CommandManager{
    private Client client;
    public ClientCommandManager(Client client){
        this.client = client;
        addCommand(new Exit());
        addCommand(new Help());
    }
    public Client getClient(){
        return client;
    }
    @Override
    public AnswerMsg runCommand(Request request) {
        AnswerMsg res = new AnswerMsg();
        if(hasCommand(request)){
            Command cmd = getCommand(request);
            cmd.setArgument(request);
            res = (AnswerMsg) cmd.run();
        }else{
            try{
                client.send(request);
                res = (AnswerMsg)client.receive();
            }catch (Exception exception){
                res.info("no attempts left, shutting down");
                res.error(exception.getMessage());
            }
        }
        System.out.println(res);
        return res;
    }
}
