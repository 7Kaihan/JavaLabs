package org.example.commands;

public class Help extends CommandImplementation{
    public Help(){
        super("help",CommandType.NORMAL);
    }
    @Override
    public String execute(){
        return CommandManager.getHelp();
    }
}
