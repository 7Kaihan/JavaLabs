package org.example;

import org.example.client.Client;

import java.io.PrintStream;

public class Main {
    private static String ADDRESS = System.getenv("address");
    private static String PORT = System.getenv("port");
    public static void main(String[] args) throws Exception{
            System.setOut(new PrintStream(System.out, true, "UTF-8"));
            String address;
            int port;
            try {
                if (ADDRESS.equals("") || PORT.equals(""))
                    throw new RuntimeException("Invalid address or port");
                address = ADDRESS;
                try {
                    port = Integer.parseInt(PORT);
                } catch (NumberFormatException exception) {
                    throw new RuntimeException("Invalid port");
                }
                Client client = new Client(address, port);
                client.start();
            }catch (RuntimeException exception){
                System.out.println(exception.getMessage());
            }

    }
}