package org.example.commands;

public class Exit extends CommandImplementation{

    public Exit() {
        super("exit", CommandType.NORMAL);
    }

    @Override
    public String execute() {
        throw new RuntimeException("shutting down");
    }
}
