package org.example.client;

import org.example.Request.Request;
import org.example.Response.Response;
import org.example.commands.ClientCommandManager;
import java.io.Closeable;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.*;

public class Client extends Thread implements Closeable {
    private SocketAddress address;
    private Socket socket;
    public final int MAX_TIME_OUT = 1000;
    public final int MAX_ATTEMPTS = 3;
    private boolean running;
    private ClientCommandManager commandManager;
    private void inti(String address, int port)throws Exception{
        connect(address,port);
        running = true;
        commandManager = new ClientCommandManager(this);
        setName("client thread");
    }
    public Client(String address,int port)throws Exception{
        inti(address,port);
    }
    public void connect(String address,int port) throws Exception{
        try{
            this.address = new InetSocketAddress(InetAddress.getByName(address),port);
        }catch (UnknownHostException exception){

        }catch (IllegalArgumentException exception){

        }try{
            socket = new Socket(address,port);
            socket.setSoTimeout(MAX_TIME_OUT);
        }catch (IOException exception){
            throw new RuntimeException("can't open the socket");
        }
    }
    public void send(Request request)throws Exception{
        try{
            ObjectOutputStream  outputStream = new ObjectOutputStream(
                    socket.getOutputStream()
            );
            outputStream.writeObject(request);
            outputStream.close();
        }catch (IOException exception){
            throw new RuntimeException("something went wrong while sending the message");
        }
    }
    public Response receive()throws Exception{
        try{
            ObjectInputStream inputStream = new ObjectInputStream(
                    socket.getInputStream()
            );
            return (Response) inputStream.readObject();
        }catch (ClassCastException | ClassNotFoundException |IOException exception){
            throw new RuntimeException("something went wrong during receiving ");
        }
    }
    @Override
    public void run(){
        commandManager.consoleMode();
        close();
    }
    @Override
    public void close(){
        try {
            running = false;
            commandManager.close();
            socket.close();
        }catch (IOException exception){
            System.out.println("can't close the socket");
        }
    }
}
